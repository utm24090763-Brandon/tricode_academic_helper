use sqlx::{PgPool, postgres::{PgPoolOptions, PgConnectOptions}};
use std::{time::Duration, str::FromStr};

pub async fn create_pool(database_url: &str) -> Result<PgPool, sqlx::Error> {
    let connect_options = PgConnectOptions::from_str(database_url)
        .expect("❌ Invalid DATABASE_URL")
        .statement_cache_capacity(100); // 👈 🔥 AUMENTA EL CACHE PARA REUTILIZAR STATEMENTS

    PgPoolOptions::new()
        .max_connections(5)
        .acquire_timeout(Duration::from_secs(5))
        .connect_with(connect_options)
        .await
}