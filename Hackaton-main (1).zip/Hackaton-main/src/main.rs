use dotenvy::dotenv;
use std::env;

mod app;
mod db;

mod handlers;
mod models;

mod routes;

#[tokio::main]
async fn main() {
    dotenv().ok();
    
    let database_url =
        env::var("DATABASE_URL").expect("DATABASE_URL not set");

    let pool = match db::create_pool(&database_url).await {
        Ok(p) => {
            println!("✅ Conectado a la base de datos exitosamente");
            p
        }
        Err(e) => {
            eprintln!("❌ Error conectando a la base de datos: {}", e);
            std::process::exit(1);
        }
    };

    let app = app::create_app(pool);

    let listener = tokio::net::TcpListener::bind("0.0.0.0:3000")
        .await
        .unwrap();

    println!("🚀 Server running on http://localhost:3000");
   
    axum::serve(listener, app).await.unwrap();
}