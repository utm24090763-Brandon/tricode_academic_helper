use axum::Router;
use sqlx::PgPool;


use crate::routes;

#[derive(Clone)]
pub struct AppState {
    pub db: PgPool,
}

pub fn create_app(db: PgPool) -> Router {
    let state = AppState { db };

    Router::new()
        .merge(routes::health::routes())
        .merge(routes::user::routes())
        .with_state(state)
}
