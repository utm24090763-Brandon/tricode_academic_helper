use axum::{routing::{get, post}, Router};

use crate::app::AppState;
use crate::handlers::users::*;

pub fn routes() -> Router<AppState> {
    Router::new()
        .route("/users", post(create_user).get(list_users))
        .route(
            "/users/:id",
            get(get_user)
                .put(update_user)
                .delete(delete_user),
        )
}