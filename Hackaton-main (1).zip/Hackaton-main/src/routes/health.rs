use axum::{
    extract::State,
    routing::get,
    Router,
    http::StatusCode,
};

use crate::app::AppState;

pub fn routes() -> Router<AppState> {
    Router::new().route("/health", get(health_check))
}

async fn health_check(
    State(state): State<AppState>,
) -> Result<&'static str, StatusCode> {

    let result = sqlx::query("SELECT 1")
        .execute(&state.db)
        .await;

    match result {
        Ok(_) => Ok("✅ DB connection OK"),
        Err(_) => Err(StatusCode::INTERNAL_SERVER_ERROR),
    }
}