use axum::{
    extract::{Path, State},
    http::StatusCode,
    Json,
};
use sqlx::Row;
use uuid::Uuid;

use crate::app::AppState;
use crate::models::users::{CreateUser, UpdateUser, User};

pub async fn create_user(
    State(state): State<AppState>,
    Json(payload): Json<CreateUser>,
) -> Result<(StatusCode, Json<User>), StatusCode> {

    let password_hash = format!("hashed-{}", payload.password);

    let row = sqlx::query(
        r#"
        INSERT INTO "user" (email, password_hash)
        VALUES ($1, $2)
        RETURNING user_id, email, is_active
        "#
    )
    .bind(payload.email)
    .bind(password_hash)
    .fetch_one(&state.db)
    .await;

    let user = match row {
        Ok(r) => User {
            user_id: r.get("user_id"),
            email: r.get("email"),
            is_active: r.get("is_active"),
        },
        Err(e) => {

            eprintln!("DB Error in create_user: {}", e);
            return Err(StatusCode::INTERNAL_SERVER_ERROR);
            
        }
    };

    Ok((StatusCode::CREATED, Json(user)))
}

pub async fn list_users(
    State(state): State<AppState>,
) -> Result<Json<Vec<User>>, StatusCode> {

    let rows = sqlx::query(
        r#"
        SELECT user_id, email, is_active
        FROM "user"
        ORDER BY created_at DESC
        "#
    )
    .fetch_all(&state.db)
    .await
    .map_err(|_| StatusCode::INTERNAL_SERVER_ERROR)?;

    let users: Vec<User> = rows
        .into_iter()
        .map(|row| User {
            user_id: row.get("user_id"),
            email: row.get("email"),
            is_active: row.get("is_active"),
        })
        .collect();

    Ok(Json(users))
}

pub async fn get_user(
    State(state): State<AppState>,
    Path(user_id): Path<Uuid>,
) -> Result<Json<User>, StatusCode> {

    let row = sqlx::query(
        r#"
        SELECT user_id, email, is_active
        FROM "user"
        WHERE user_id = $1
        "#
    )
    .bind(user_id)
    .fetch_optional(&state.db)
    .await
    .map_err(|_| StatusCode::INTERNAL_SERVER_ERROR)?;

    let user = row.map(|r| User {
        user_id: r.get("user_id"),
        email: r.get("email"),
        is_active: r.get("is_active"),
    });

    match user {
        Some(u) => Ok(Json(u)),
        None => Err(StatusCode::NOT_FOUND),
    }
}

pub async fn update_user(
    State(state): State<AppState>,
    Path(user_id): Path<Uuid>,
    Json(payload): Json<UpdateUser>,
) -> Result<Json<User>, StatusCode> {

    let row = sqlx::query(
        r#"
        UPDATE "user"
        SET
            email = COALESCE($1, email),
            is_active = COALESCE($2, is_active),
            updated_at = now()
        WHERE user_id = $3
        RETURNING user_id, email, is_active
        "#
    )
    .bind(payload.email)
    .bind(payload.is_active)
    .bind(user_id)
    .fetch_optional(&state.db)
    .await
    .map_err(|_| StatusCode::INTERNAL_SERVER_ERROR)?;

    let user = row.map(|r| User {
        user_id: r.get("user_id"),
        email: r.get("email"),
        is_active: r.get("is_active"),
    });

    match user {
        Some(u) => Ok(Json(u)),
        None => Err(StatusCode::NOT_FOUND),
    }
}

pub async fn delete_user(
    State(state): State<AppState>,
    Path(user_id): Path<Uuid>,
) -> Result<StatusCode, StatusCode> {

    let result = sqlx::query(
        r#"
        DELETE FROM "user"
        WHERE user_id = $1
        "#
    )
    .bind(user_id)
    .execute(&state.db)
    .await
    .map_err(|_| StatusCode::INTERNAL_SERVER_ERROR)?;

    if result.rows_affected() == 0 {
        Err(StatusCode::NOT_FOUND)
    } else {
        Ok(StatusCode::NO_CONTENT)
    }
}